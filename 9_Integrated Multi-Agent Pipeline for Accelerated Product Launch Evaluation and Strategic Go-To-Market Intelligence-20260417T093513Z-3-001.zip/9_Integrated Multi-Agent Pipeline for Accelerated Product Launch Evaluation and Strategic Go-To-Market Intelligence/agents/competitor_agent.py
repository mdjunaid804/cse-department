from agents.llm import get_llm

def competitor_agent(retriever, query):
    llm = get_llm()

    docs = retriever.invoke(query)   # ✅ FIXED

    context = "\n".join([doc.page_content for doc in docs])

    prompt = f"""
    You are a GTM strategist.

    Context:
    {context}

    Task:
    Analyze competitor strategy for: {query}

    Output:
    - Positioning
    - Strengths
    - Weaknesses
    - Strategic Insights
    """

    return llm.invoke(prompt).content