def metrics_agent(llm, query):
    return llm.invoke(
        f"Provide launch KPIs for {query}"
    ).content   # ✅ FIXED