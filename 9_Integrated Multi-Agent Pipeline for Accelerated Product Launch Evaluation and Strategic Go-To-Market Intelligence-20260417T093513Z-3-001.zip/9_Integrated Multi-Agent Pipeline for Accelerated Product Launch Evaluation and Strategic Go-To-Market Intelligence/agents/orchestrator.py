from agents.competitor_agent import competitor_agent
from agents.sentiment_agent import sentiment_agent
from agents.metrics_agent import metrics_agent
from agents.pricing_agent import pricing_agent
from agents.trend_agent import trend_agent
from agents.llm import get_llm


def run_pipeline(retriever, query):

    llm = get_llm()

    comp = competitor_agent(retriever, query)
    sent = sentiment_agent(llm, query)
    metrics = metrics_agent(llm, query)
    pricing = pricing_agent(llm, query)
    trends = trend_agent(llm, query)

    # 🔥 Final combined report
    final_prompt = f"""
    Create a structured GTM report using:

    Competitor:
    {comp}

    Sentiment:
    {sent}

    Metrics:
    {metrics}

    Pricing:
    {pricing}

    Trends:
    {trends}

    Output:
    - Executive Summary
    - Key Insights
    - Recommendations
    """

    final_output = llm.invoke(final_prompt).content

    # ✅ RETURN DICTIONARY (IMPORTANT FIX)
    return {
        "comp": comp,
        "sent": sent,
        "metrics": metrics,
        "pricing": pricing,
        "trends": trends,
        "final": final_output
    }