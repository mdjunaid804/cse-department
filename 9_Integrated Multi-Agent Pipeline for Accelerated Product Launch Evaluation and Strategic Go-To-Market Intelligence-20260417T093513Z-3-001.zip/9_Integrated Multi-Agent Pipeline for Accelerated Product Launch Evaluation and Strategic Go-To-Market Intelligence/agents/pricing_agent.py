def pricing_agent(llm, query):
    return llm.invoke(
        f"Analyze pricing strategy of {query}"
    ).content   # ✅ FIXED