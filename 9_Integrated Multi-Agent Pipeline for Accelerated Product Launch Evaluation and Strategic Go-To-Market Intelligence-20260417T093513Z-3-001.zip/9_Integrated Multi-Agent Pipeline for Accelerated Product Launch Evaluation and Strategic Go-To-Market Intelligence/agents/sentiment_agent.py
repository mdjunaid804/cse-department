def sentiment_agent(llm, query):
    prompt = f"""
    Analyze market sentiment for {query}.

    Provide:
    - Positive factors
    - Negative factors
    - Summary
    """
    return llm.invoke(prompt).content   # ✅ FIXED