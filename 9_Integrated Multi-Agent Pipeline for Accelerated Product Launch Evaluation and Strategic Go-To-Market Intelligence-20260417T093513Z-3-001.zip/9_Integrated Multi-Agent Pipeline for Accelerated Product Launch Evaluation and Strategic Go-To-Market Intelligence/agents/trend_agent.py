def trend_agent(llm, query):
    return llm.invoke(
        f"Predict future trends for {query}"
    ).content   # ✅ FIXED