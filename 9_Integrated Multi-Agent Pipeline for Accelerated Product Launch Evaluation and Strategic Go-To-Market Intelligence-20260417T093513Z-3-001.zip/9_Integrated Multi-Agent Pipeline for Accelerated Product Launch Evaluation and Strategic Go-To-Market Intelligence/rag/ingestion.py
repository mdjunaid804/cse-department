import os

def load_documents():
    docs = []
    for file in os.listdir("data/docs"):
        with open(f"data/docs/{file}", "r", encoding="utf-8") as f:
            docs.append(f.read())
    return docs