from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough

def get_retriever(vectorstore):
    return vectorstore.as_retriever(search_kwargs={"k": 5})