function loadSection(section) {

    const loader = document.getElementById("loader");
    const contentBox = document.getElementById("contentBox");
    const content = document.getElementById("sectionContent");
    const title = document.getElementById("sectionTitle");

    const titles = {
        comp: "Competitor Analysis",
        sent: "Market Sentiment",
        metrics: "Metrics",
        pricing: "Pricing Strategy",
        trends: "Trends",
        final: "Executive Summary"
    };

    // Show loader
    contentBox.style.display = "none";
    loader.classList.remove("d-none");

    setTimeout(() => {

        // 🔥 GET CONTENT FROM HIDDEN DIVS
        const sectionData = document.getElementById(section).innerHTML;

        content.innerHTML = sectionData;
        title.innerText = titles[section];

        loader.classList.add("d-none");
        contentBox.style.display = "block";

    }, 800);
}